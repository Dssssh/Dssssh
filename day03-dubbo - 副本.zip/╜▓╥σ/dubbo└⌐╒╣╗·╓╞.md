# Dubbo扩展点

## 概述

**来源**：

Dubbo 的扩展点加载从 JDK 标准的 SPI (Service Provider Interface) 扩展点发现机制加强而来。

Dubbo 改进了 JDK 标准的 SPI 的以下问题：

- JDK 标准的 SPI 会一次性实例化扩展点所有实现，如果有扩展实现初始化很耗时，但如果没用上也加载，会很浪费资源。
- 如果扩展点加载失败，连扩展点的名称都拿不到了。比如：JDK 标准的 ScriptEngine，通过 `getName()` 获取脚本类型的名称，但如果 RubyScriptEngine 因为所依赖的 jruby.jar 不存在，导致 RubyScriptEngine 类加载失败，这个失败原因被吃掉了，和 ruby 对应不起来，当用户执行 ruby 脚本时，会报不支持 ruby，而不是真正失败的原因。
- 增加了对扩展点 IoC 和 AOP 的支持，一个扩展点可以直接 setter 注入其它扩展点。

**约定**：

在扩展类的 jar 包内 [[1\]](http://dubbo.apache.org/zh-cn/docs/dev/SPI.html#fn1)，放置扩展点配置文件 `META-INF/dubbo/接口全限定名`，内容为：`配置名=扩展实现类全限定名`，多个实现类用换行符分隔。

**示例**：

以扩展 Dubbo 的协议为例，在协议的实现 jar 包内放置文本文件：`META-INF/dubbo/org.apache.dubbo.rpc.Protocol`，内容为：

```properties
xxx=com.alibaba.xxx.XxxProtocol
```

## 过滤器使用

1.创建一个自定义类实现org.apache.dubbo.rpc.Filter接口

2.在类上加注解@Activate（org.apache.dubbo.common.extension.Activate）,group = {CommonConstants.CONSUMER}指定为消费方使用。

3.实现invoke方法，并最后调用invoker.invoke(invocation)返回下一个过滤器

示例代码：

```java
package com.itheima.web;

import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;

@Activate(group = {CommonConstants.CONSUMER})
public class MyFilter implements Filter{
    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        System.out.println("调用服务方的端口:" + invoker.getUrl().getPort());
        return invoker.invoke(invocation);
    }
}
```

4.在resources下新建META-INF目录，然后在META-INF下面创建dubbo文件夹。在dubbo目录下创建一个文件名为org.apache.dubbo.rpc.Filter的文件，该文件不需要文件扩展名。

具体内容：

```properties
myFilter=com.itheima.web.MyFilter
```

![](media/30.png)

# Dubbo整体架构设计

![](media/31.jpg)

图例说明：

- 图中左边淡蓝背景的为服务消费方使用的接口，右边淡绿色背景的为服务提供方使用的接口，位于中轴线上的为双方都用到的接口。
- 图中从下至上分为十层，各层均为单向依赖，右边的黑色箭头代表层之间的依赖关系，每一层都可以剥离上层被复用，其中，Service 和 Config 层为 API，其它各层均为 SPI。
- 图中绿色小块的为扩展接口，蓝色小块为实现类，图中只显示用于关联各层的实现类。
- 图中蓝色虚线为初始化过程，即启动时组装链，红色实线为方法调用过程，即运行时调时链，紫色三角箭头为继承，可以把子类看作父类的同一个节点，线上的文字为调用的方法。