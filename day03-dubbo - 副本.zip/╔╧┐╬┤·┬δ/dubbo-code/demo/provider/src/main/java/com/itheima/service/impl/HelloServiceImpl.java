package com.itheima.service.impl;

import service.HelloService;

public class HelloServiceImpl implements HelloService {

    public String sayHello(String name) {
        return "hello:" + name;
    }

}
