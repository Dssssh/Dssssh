package com.itheima;

import org.apache.dubbo.config.ApplicationConfig;
import org.apache.dubbo.config.ReferenceConfig;
import org.apache.dubbo.config.RegistryConfig;
import service.HelloService;

import java.io.IOException;

public class Consumer {

    public static void main(String[] args) throws IOException {
        // 当前应用配置
        ApplicationConfig application = new ApplicationConfig();
        application.setName("consumer-dubbo");

// 连接注册中心配置 -  不适用注册中心
        RegistryConfig registry = new RegistryConfig("zookeeper://localhost:2181");

// 注意：ReferenceConfig为重对象，内部封装了与注册中心的连接，以及与服务提供方的连接

// 引用远程服务
        ReferenceConfig<HelloService> reference = new ReferenceConfig<HelloService>(); // 此实例很重，封装了与注册中心的连接以及与提供者的连接，请自行缓存，否则可能造成内存和连接泄漏
        reference.setApplication(application);
        reference.setRegistry(registry); // 多个注册中心可以用setRegistries()
        reference.setInterface(HelloService.class);
// 如果点对点直连，可以用reference.setUrl()指定目标地址，设置url后将绕过注册中心，
// 将服务端日志发布的url地址拷贝到setUrl方法参数中
//        reference.setUrl("dubbo://10.254.142.13:20880/service.HelloService");

// 和本地bean一样使用xxxService
        HelloService helloService = reference.get(); // 注意：此代理对象内部封装了所有通讯细节，对象较重，请缓存复用

        String heima = helloService.sayHello("heima");

        System.out.println(heima+"===============");
        //  模拟服务启动--  当前线程阻塞
        System.in.read();

    }

}
