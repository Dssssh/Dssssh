package com.itheima;

public interface HelloService {

    public String sayHello(String name);

}
