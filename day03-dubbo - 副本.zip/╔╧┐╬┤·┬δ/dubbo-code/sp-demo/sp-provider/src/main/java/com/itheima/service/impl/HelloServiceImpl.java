package com.itheima.service.impl;

import com.itheima.HelloService;
import org.apache.dubbo.config.annotation.Service;
import org.apache.dubbo.rpc.RpcContext;

import java.util.Random;

@Service
public class HelloServiceImpl implements HelloService {

    private static Integer count = 0;

    @Override
    public String sayHello(String name) {
        System.out.println("userId:" + RpcContext.getContext().getAttachment("userId"));
        System.out.println("我被调用了:" + (++count));
//        try {
//            Thread.sleep(2000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        return "hello:" + name;
    }
}
