package com.itheima.web;

import com.itheima.HelloService;
import org.apache.dubbo.config.annotation.Reference;
import org.apache.dubbo.rpc.RpcContext;
import org.springframework.web.bind.annotation.*;

@RestController
public class HelloController {

    @Reference(check = false,mock = "com.itheima.HelloServiceMock")
    private HelloService helloService;

    @GetMapping("/sayHello/{name}")
    public String sayHello(@PathVariable("name") String name){
        RpcContext.getContext().setAttachment("userId","1");
        return helloService.sayHello(name);
    }

}
