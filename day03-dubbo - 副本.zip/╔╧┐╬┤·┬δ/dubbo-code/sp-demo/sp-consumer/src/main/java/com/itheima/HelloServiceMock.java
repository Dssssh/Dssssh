package com.itheima;

public class HelloServiceMock implements HelloService {

    @Override
    public String sayHello(String name) {
        return "mock:" + name;
    }

}
