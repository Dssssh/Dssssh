package com.itheima.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.itheima.pojo.User;

public interface UserMapper extends BaseMapper<User> {
}
